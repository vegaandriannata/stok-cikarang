-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2024 at 08:03 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cikarang-stok`
--

-- --------------------------------------------------------

--
-- Table structure for table `alasan_claim`
--

CREATE TABLE `alasan_claim` (
  `id_a_c` int(11) NOT NULL,
  `alasan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alasan_claim`
--

INSERT INTO `alasan_claim` (`id_a_c`, `alasan`) VALUES
(18, 'Bintik'),
(19, 'Lecek'),
(20, 'Baret'),
(21, 'Mata Ikan'),
(22, 'Gelembung');

-- --------------------------------------------------------

--
-- Table structure for table `claim_xforce`
--

CREATE TABLE `claim_xforce` (
  `id_c_xforce` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `shift` varchar(20) NOT NULL,
  `keterangan` text NOT NULL,
  `line` int(11) NOT NULL,
  `nama_teknisi` varchar(20) NOT NULL,
  `no_rangka` varchar(30) NOT NULL,
  `deskripsi` varchar(50) NOT NULL,
  `tipe_mobil` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `kdp` int(11) NOT NULL,
  `kbg` int(11) NOT NULL,
  `kpkr` int(11) NOT NULL,
  `kpkn` int(11) NOT NULL,
  `kskr` int(11) NOT NULL,
  `kskn` int(11) NOT NULL,
  `kmkr` int(11) NOT NULL,
  `kmkn` int(11) NOT NULL,
  `alasan_kdp` varchar(255) DEFAULT NULL,
  `alasan_kbg` varchar(255) DEFAULT NULL,
  `alasan_kpkr` varchar(255) DEFAULT NULL,
  `alasan_kpkn` varchar(255) DEFAULT NULL,
  `alasan_kskr` varchar(255) DEFAULT NULL,
  `alasan_kskn` varchar(255) DEFAULT NULL,
  `alasan_kmkr` varchar(255) DEFAULT NULL,
  `alasan_kmkn` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `claim_xpander`
--

CREATE TABLE `claim_xpander` (
  `id_c_xpander` int(5) NOT NULL,
  `tanggal` date NOT NULL,
  `shift` varchar(20) NOT NULL,
  `line` int(11) NOT NULL,
  `nama_teknisi` varchar(20) NOT NULL,
  `keterangan` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `tipe_mobil` varchar(20) NOT NULL,
  `no_rangka` varchar(50) NOT NULL,
  `deskripsi` varchar(50) NOT NULL,
  `kdp` int(11) NOT NULL,
  `kbg` int(11) NOT NULL,
  `kpkr` int(11) NOT NULL,
  `kpkn` int(11) NOT NULL,
  `kskr` int(11) NOT NULL,
  `kskn` int(11) NOT NULL,
  `kmdkr` int(11) NOT NULL,
  `kmdkn` int(11) NOT NULL,
  `kmbkr` int(11) NOT NULL,
  `kmbkn` int(11) NOT NULL,
  `alasan_kdp` varchar(255) DEFAULT NULL,
  `alasan_kbg` varchar(255) DEFAULT NULL,
  `alasan_kpkr` varchar(255) DEFAULT NULL,
  `alasan_kpkn` varchar(255) DEFAULT NULL,
  `alasan_kskr` varchar(255) DEFAULT NULL,
  `alasan_kskn` varchar(255) DEFAULT NULL,
  `alasan_kmdkr` varchar(255) DEFAULT NULL,
  `alasan_kmdkn` varchar(255) DEFAULT NULL,
  `alasan_kmbkr` varchar(255) DEFAULT NULL,
  `alasan_kmbkn` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `histori_activity`
--

CREATE TABLE `histori_activity` (
  `id_act` int(255) NOT NULL,
  `user` varchar(20) NOT NULL,
  `url` varchar(50) NOT NULL,
  `data` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `action` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `histori_activity`
--

INSERT INTO `histori_activity` (`id_act`, `user`, `url`, `data`, `tanggal`, `action`) VALUES
(109, 'vega', 'http://localhost/stokckg/register.php', 'Andhika+Andhika+Andhika123', '2024-01-23', 'insert');

-- --------------------------------------------------------

--
-- Table structure for table `ht_xforce`
--

CREATE TABLE `ht_xforce` (
  `id_htxf` int(5) NOT NULL,
  `tanggal` date NOT NULL,
  `shift` varchar(20) NOT NULL,
  `nama_teknisi` varchar(20) NOT NULL,
  `tdp` int(11) NOT NULL,
  `tbg` int(11) NOT NULL,
  `hdp` int(11) NOT NULL,
  `hbg` int(11) NOT NULL,
  `cdp` int(11) NOT NULL,
  `cbg` int(11) NOT NULL,
  `sdp` int(11) NOT NULL,
  `sbg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ht_xpander`
--

CREATE TABLE `ht_xpander` (
  `id_htxp` int(5) NOT NULL,
  `tanggal` date NOT NULL,
  `shift` varchar(20) NOT NULL,
  `nama_teknisi` varchar(20) NOT NULL,
  `tdp` int(11) NOT NULL,
  `tbg` int(11) NOT NULL,
  `hdp` int(11) NOT NULL,
  `hbg` int(11) NOT NULL,
  `cdp` int(11) NOT NULL,
  `cbg` int(11) NOT NULL,
  `sdp` int(11) NOT NULL,
  `sbg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `mt_xforce`
--

CREATE TABLE `mt_xforce` (
  `id_mtxf` int(5) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` text NOT NULL,
  `deskripsi` text NOT NULL,
  `kdp` int(11) NOT NULL,
  `kbg` int(11) NOT NULL,
  `kpkr` int(11) NOT NULL,
  `kpkn` int(11) NOT NULL,
  `kskr` int(11) NOT NULL,
  `kskn` int(11) NOT NULL,
  `kmkr` int(11) NOT NULL,
  `kmkn` int(11) NOT NULL,
  `htdp` int(11) NOT NULL,
  `htbg` int(11) NOT NULL,
  `shift` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `mt_xpander`
--

CREATE TABLE `mt_xpander` (
  `id_mtxp` int(5) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` text NOT NULL,
  `deskripsi` text NOT NULL,
  `kdp` int(11) NOT NULL,
  `kbg` int(11) NOT NULL,
  `kpkr` int(11) NOT NULL,
  `kpkn` int(11) NOT NULL,
  `kskr` int(11) NOT NULL,
  `kskn` int(11) NOT NULL,
  `kmdkr` int(11) NOT NULL,
  `kmdkn` int(11) NOT NULL,
  `kmbkr` int(11) NOT NULL,
  `kmbkn` int(11) NOT NULL,
  `shift` varchar(20) NOT NULL,
  `htdp` int(11) NOT NULL,
  `htbg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `teknisi`
--

CREATE TABLE `teknisi` (
  `id_teknisi` int(5) NOT NULL,
  `nama_teknisi` varchar(20) NOT NULL,
  `posisi` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teknisi`
--

INSERT INTO `teknisi` (`id_teknisi`, `nama_teknisi`, `posisi`) VALUES
(32, 'Harno', 'Heating');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `username`, `password`) VALUES
(1, 'Jasen', 'Jasen', 'jasen123'),
(13, 'Vega Andriannata Atmadja', 'Vega', 'Vegaadul123'),
(14, 'Admin', 'Admin', 'Admin123'),
(25, 'Andhika', 'Andhika', 'Andhika123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alasan_claim`
--
ALTER TABLE `alasan_claim`
  ADD PRIMARY KEY (`id_a_c`);

--
-- Indexes for table `claim_xforce`
--
ALTER TABLE `claim_xforce`
  ADD PRIMARY KEY (`id_c_xforce`);

--
-- Indexes for table `claim_xpander`
--
ALTER TABLE `claim_xpander`
  ADD PRIMARY KEY (`id_c_xpander`);

--
-- Indexes for table `histori_activity`
--
ALTER TABLE `histori_activity`
  ADD PRIMARY KEY (`id_act`);

--
-- Indexes for table `ht_xforce`
--
ALTER TABLE `ht_xforce`
  ADD PRIMARY KEY (`id_htxf`);

--
-- Indexes for table `ht_xpander`
--
ALTER TABLE `ht_xpander`
  ADD PRIMARY KEY (`id_htxp`);

--
-- Indexes for table `mt_xforce`
--
ALTER TABLE `mt_xforce`
  ADD PRIMARY KEY (`id_mtxf`);

--
-- Indexes for table `mt_xpander`
--
ALTER TABLE `mt_xpander`
  ADD PRIMARY KEY (`id_mtxp`);

--
-- Indexes for table `teknisi`
--
ALTER TABLE `teknisi`
  ADD PRIMARY KEY (`id_teknisi`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alasan_claim`
--
ALTER TABLE `alasan_claim`
  MODIFY `id_a_c` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `claim_xforce`
--
ALTER TABLE `claim_xforce`
  MODIFY `id_c_xforce` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `claim_xpander`
--
ALTER TABLE `claim_xpander`
  MODIFY `id_c_xpander` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `histori_activity`
--
ALTER TABLE `histori_activity`
  MODIFY `id_act` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `ht_xforce`
--
ALTER TABLE `ht_xforce`
  MODIFY `id_htxf` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `ht_xpander`
--
ALTER TABLE `ht_xpander`
  MODIFY `id_htxp` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `mt_xforce`
--
ALTER TABLE `mt_xforce`
  MODIFY `id_mtxf` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `mt_xpander`
--
ALTER TABLE `mt_xpander`
  MODIFY `id_mtxp` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `teknisi`
--
ALTER TABLE `teknisi`
  MODIFY `id_teknisi` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
