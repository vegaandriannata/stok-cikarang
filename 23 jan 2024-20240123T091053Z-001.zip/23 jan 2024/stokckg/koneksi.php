<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "cikarang-stok";

$koneksi = mysqli_connect($host, $user, $password, $database);

if (mysqli_connect_errno()) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
