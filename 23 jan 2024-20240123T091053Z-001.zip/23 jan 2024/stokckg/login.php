<?php
session_start();
require_once 'koneksi.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Add any necessary validation or hashing for the password

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $koneksi->query($sql);

    if ($result->num_rows == 1) {
        $_SESSION['username'] = $username;
		 $_SESSION["timeout"] = PHP_INT_MAX;
        header("Location: dashboard-stok.php");
        exit();
    } else {
        $error_message = "Invalid username or password";
    }
}
if (isset($_SESSION['timeout']) && time() > $_SESSION['timeout']) {
    session_destroy();
    $error_message = "Session expired. Please login again.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add your existing head content here -->
    <!-- ... -->
	<!-- Add this line to include Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

	<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #ffffff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .error-message {
            color: red;
            margin-bottom: 10px;
        }
		.password-input-container {
            position: relative;
        }

        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 40%;
            transform: translateY(-50%);
        }
    </style>
</head>
<body>

    

     <form method="post" action="">
        <h2 style="text-align:center;">Login</h2>
        <label for="username">Username:</label>
        <input type="text" name="username" required><br>

        <label for="password">Password:</label>
        <!-- Add a container for the password input -->
        <div class="password-input-container">
            <input type="password" name="password" id="password" required>
            <!-- Add Font Awesome icon inside the container -->
            <span class="password-toggle" onclick="togglePassword()">
                <i class="fas fa-eye"></i>
            </span>
        </div>

        <input type="submit" name="login" value="Login">
		<?php
    if (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
    }
    ?>
    </form>

    <script>
        function togglePassword() {
            var passwordInput = document.getElementById('password');
            var passwordToggle = document.querySelector('.password-toggle');

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                passwordToggle.innerHTML = '<i class="fas fa-eye-slash"></i>';
            } else {
                passwordInput.type = 'password';
                passwordToggle.innerHTML = '<i class="fas fa-eye"></i>';
            }
        }
    </script>

</body>
</html>
