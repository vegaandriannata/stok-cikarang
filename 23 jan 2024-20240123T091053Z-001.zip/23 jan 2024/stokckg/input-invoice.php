
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Input Stok Claim Xforce</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        form {
            max-width: 100%;
            margin: auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, select, textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
	<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        font-size: 14px;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        background-color: #f4f4f4; /* Light gray background color */
    }

    h1 {
        text-align: center;
        margin: 20px 0;
    }

    .container {
        display: flex;
        flex: 1;
    }

    .sidebar {
        background-color: #344; /* Dark background color */
        padding: 20px;
        min-width: 200px;
        box-sizing: border-box;
        color: white;
    }
    .header {
        background-color: #333; /* Dark background color */
        padding: 10px;
        min-width: 200px;
        box-sizing: border-box;
        color: white;
    }

    .menu a {
        text-decoration: none;
        padding: 10px;
        color: white;
        border-radius: 5px;
        margin-bottom: 10px;
        display: block;
        transition: background-color 0.3s;
    }

    .menu a:hover {
        background-color: #555; /* Slightly darker color on hover */
    }

    .logout {
        text-align: center;
        margin-top: auto;
    }

    .logout a {
        text-decoration: none;
        padding: 10px;
        background-color: #d32f2f; /* Red color for logout button */
        color: white;
        border-radius: 5px;
        display: block;
        transition: background-color 0.3s;
    }

    .logout a:hover {
        background-color: #b71c1c; /* Slightly darker red on hover */
    }

    .content {
        padding: 20px;
        flex: 1;
        background-color: white; /* White background color for content */
    }
    </style>
</head>
<body>
<div class="header">
    <h1>Dashboard Laporan Stok</h1>
</div>
<div class="container">

        <!-- Sidebar -->
        <div class="sidebar">
            <div class="menu">
                 <div class="menu">
                <a href="">Create Invoice</a>
                <a href="">Master Data Customer</a>
                <a href="">Master Data Car Brand</a>
                <a href="">Master Data Car Type</a>
            </div>
            </div>
            <div class="logout">
                <a href="logout.php">Logout</a>
            </div>
        </div>
<div class="content">
    <h1>Form Input Stok Claim Xforce</h1>

    <?php echo $pesan;  ?>

    <form action="" method="post">
	<div style="display: flex; flex-wrap: wrap;">

    <!-- Section 1 -->
 <!-- Section 1 -->
<div style="flex: 0 0 49%; margin-right: 2%;">
        <label for="tanggal">Tanggal:</label>
        <input type="date" id="tanggal" name="tanggal" value="<?php echo $tanggal; ?>" required>

		 <label for="shift">Shift:</label>
        <select id="shift" name="shift" required>
            <option value="Pagi" <?php echo ($shift == 'Pagi') ? 'selected' : ''; ?>>Pagi</option>
            <option value="Malam" <?php echo ($shift == 'Malam') ? 'selected' : ''; ?>>Malam</option>
        </select>

        <label for="keterangan">Keterangan:</label>
        <select id="keterangan" name="keterangan" required>
            <option value="Stok Masuk" <?php echo ($keterangan == 'Stok Masuk') ? 'selected' : ''; ?>>Stok Masuk</option>
            <option value="Stok Keluar" <?php echo ($keterangan == 'Stok Keluar') ? 'selected' : ''; ?>>Stok Keluar</option>
        </select>
		
        <label for="tipe_mobil">Tipe Mobil:</label>
        <select id="tipe_mobil" name="tipe_mobil" required>
            <option value="Xforce Exceed" <?php echo ($tipe_mobil == 'Xforce Exceed') ? 'selected' : ''; ?>>Xforce Exceed</option>
            <option value="Xforce Ultimate" <?php echo ($tipe_mobil == 'Xforce Ultimate') ? 'selected' : ''; ?>>Xforce Ultimate</option>
           
        </select>
		</div>
<!-- Section 2 -->
<div style="flex: 0 0 49%; ">
		<label for="status">Status:</label>
        <select id="status" name="status" required>
            <option value="Claim" <?php echo ($status == 'Claim') ? 'selected' : ''; ?>>Claim</option>
            <option value="Reject" <?php echo ($status == 'Reject') ? 'selected' : ''; ?>>Reject</option>
        </select>

		<label for="nama_teknisi">Nama Teknisi:</label>
		<select id="nama_teknisi" name="nama_teknisi" required>
			<?php echo $teknisi_options; ?>
		</select>
		
		<label for="no_rangka">Nomor Rangka:</label>
		<input type="text" id="no_rangka" name="no_rangka" value="<?php echo $no_rangka; ?>" required>
		
		
		<label for="line">Line:</label>
        <select id="line" name="line" required>
            <option value="1" <?php echo ($line == '1') ? 'selected' : ''; ?>>1</option>
            <option value="2" <?php echo ($line == '2') ? 'selected' : ''; ?>>2</option>
			<option value="3" <?php echo ($line == '3') ? 'selected' : ''; ?>>3</option>
            <option value="4" <?php echo ($line == '4') ? 'selected' : ''; ?>>4</option>
			<option value="5" <?php echo ($line == '5') ? 'selected' : ''; ?>>5</option>
            <option value="6" <?php echo ($line == '6') ? 'selected' : ''; ?>>6</option>
			
        </select>
</div></div>
		<p>Bagian Kaca</p>
		<div style="display: flex; flex-wrap: wrap;">

    <!-- Section 1 -->
 <!-- Section 1 -->
<div style="flex: 0 0 22%; margin-right: 4%;">
    <label for="kdp">Kaca Depan:</label>
    <input type="text" id="kdp" name="kdp" value="<?php echo $kdp; ?>" >
    <select id="alasan_kdp" name="alasan_kdp">
        <option value=""></option>
		<option value="baret">Baret</option>
        <option value="bintik">Bintik</option>
        <option value="lecek">Lecek</option>
    </select>

    <label for="kbg">Kaca Bagasi:</label>
    <input type="text" id="kbg" name="kbg" value="<?php echo $kbg; ?>" >
    <select id="alasan_kbg" name="alasan_kbg">
	 <option value=""></option>
        <option value="baret">Baret</option>
        <option value="bintik">Bintik</option>
        <option value="lecek">Lecek</option>
    </select>
</div>
<!-- Section 2 -->
<div style="flex: 0 0 22%; margin-right: 4%;">
    <label for="kpkr">Kaca Penumpang Kiri:</label>
    <input type="text" id="kpkr" name="kpkr" value="<?php echo $kpkr; ?>" >
    <select id="alasan_kpkr" name="alasan_kpkr">
	 <option value=""></option>
        <option value="baret">Baret</option>
        <option value="bintik">Bintik</option>
        <option value="lecek">Lecek</option>
    </select>

    <label for="kpkn">Kaca Penumpang Kanan:</label>
    <input type="text" id="kpkn" name="kpkn" value="<?php echo $kpkn; ?>" >
    <select id="alasan_kpkn" name="alasan_kpkn">
	 <option value=""></option>
        <option value="baret">Baret</option>
        <option value="bintik">Bintik</option>
        <option value="lecek">Lecek</option>
    </select>
</div>
<!-- Section 3 -->
<div style="flex: 0 0 22%; margin-right: 4%;">
    <label for="kskr">Kaca Sopir Kiri:</label>
    <input type="text" id="kskr" name="kskr" value="<?php echo $kskr; ?>" >
    <select id="alasan_kskr" name="alasan_kskr">
	 <option value=""></option>
        <option value="baret">Baret</option>
        <option value="bintik">Bintik</option>
        <option value="lecek">Lecek</option>
    </select>

    <label for="kskn">Kaca Sopir Kanan:</label>
    <input type="text" id="kskn" name="kskn" value="<?php echo $kskn; ?>" >
    <select id="alasan_kskn" name="alasan_kskn">
	 <option value=""></option>
        <option value="baret">Baret</option>
        <option value="bintik">Bintik</option>
        <option value="lecek">Lecek</option>
    </select>
</div>

<!-- Section 5 -->
<div style="flex: 0 0 22%; ">
    <label for="kmkr">Kaca Mati Belakang Kiri:</label>
    <input type="text" id="kmkr" name="kmkr" value="<?php echo $kmkr; ?>" >
    <select id="alasan_kmkr" name="alasan_kmkr">
	 <option value=""></option>
        <option value="baret">Baret</option>
        <option value="bintik">Bintik</option>
        <option value="lecek">Lecek</option>
    </select>

    <label for="kmkn">Kaca Mati Belakang Kanan:</label>
    <input type="text" id="kmkn" name="kmkn" value="<?php echo $kmkn; ?>" >
    <select id="alasan_kmkn" name="alasan_kmkn">
	 <option value=""></option>
        <option value="baret">Baret</option>
        <option value="bintik">Bintik</option>
        <option value="lecek">Lecek</option>
    </select>
</div>

        
        <input type="submit" value="Simpan">
    </form>
	</div>
</body>
</html>